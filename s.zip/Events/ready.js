module.exports = (client) => {
      
};
//      for( ; true ; ){
//     client.user.setActivity("Lunard Bot v1 | !help | " +  `${client.guilds.cache.size} Serveur(s)`) 
//}